<?php 
	$lang['heading_about'] = "Selamat datang";
 ?>