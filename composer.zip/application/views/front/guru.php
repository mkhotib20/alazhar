<?php include 'header.php'?>
	<section id="isi" >
		<div class="row no-gutters">
			<div style="border-right: 2px solid grey;" class="col-md-4">
				<div class="profile">
					<p id="teacherBtn">Teacher</p>
					<p id="dirBtn" >Director</p>
					<p id="staffBtn" >Staff</p>
				</div>
			</div>
			<div class="col-md-8">
				<div class="profile-right">
					<div id="director">
						<div class="row no-gutters">
							<?php foreach ($dir as $r) { ?>
							<div class="col-md-3">
								<a href="<?php echo base_url($langID.'/profile/guru/'.$r['guru_id'].'#detail') ?>">
									<div class="frame">
										<div class="img" style="background: url('<?php echo base_url('uploads/guru/'.$r['guru_img']) ?>') no-repeat center ; background-size: cover; " >
										</div>
										<div class="capt guru">
											<p><?php echo $r['guru_nama'] ?></p>
										</div>
									</div>		
								</a>
							</div>
							<?php } ?>
						</div>
					</div>
					<div id="staff">
						<div class="row no-gutters">
							<?php foreach ($staff as $r) { ?>
							<div class="col-md-3">
								<a href="<?php echo base_url($langID.'/profile/guru/'.$r['guru_id'].'#detail') ?>">
									<div class="frame">
										<div class="img" style="background: url('<?php echo base_url('uploads/guru/'.$r['guru_img']) ?>') no-repeat center ; background-size: cover; " >
										</div>
										<div class="capt guru">
											<p><?php echo $r['guru_nama'] ?></p>
										</div>
									</div>		
								</a>
							</div>
							<?php } ?>
						</div>
					</div>
					<div id="teacher">
						<div class="row no-gutters">
							<?php foreach ($read as $r) { ?>
							<div class="col-md-3">
								<a href="<?php echo base_url($langID.'/profile/guru/'.$r['guru_id'].'#detail') ?>">
									<div class="frame">
										<div class="img" style="background: url('<?php echo base_url('uploads/guru/'.$r['guru_img']) ?>') no-repeat center ; background-size: cover; " >
										</div>
										<div class="capt guru">
											<p><?php echo $r['guru_nama'] ?></p>
										</div>
									</div>		
								</a>
							</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include 'footer.php'; ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#director').hide();
			$('#staff').hide();
			$('#teacherBtn').attr("class", "aktif-profile");
		})
		$('#teacherBtn').click(function(){
			$('#teacher').show();
			$(this).attr("class", "aktif-profile");

			$('#staffBtn').removeAttr("class");
			$('#dirBtn').removeAttr("class");
			
			$('#staff').hide();
			$('#director').hide();
		})
		$('#staffBtn').click(function(){
			$('#staff').show();
			$(this).attr("class", "aktif-profile");

			$('#teacherBtn').removeAttr("class");
			$('#dirBtn').removeAttr("class");
			
			$('#teacher').hide();
			$('#director').hide();
		})
		$('#dirBtn').click(function(){
			$('#director').show();
			$(this).attr("class", "aktif-profile");

			$('#teacherBtn').removeAttr("class");
			$('#staffBtn').removeAttr("class");
			
			$('#teacher').hide();
			$('#staff').hide();
		})

	</script>