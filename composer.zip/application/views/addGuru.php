<?php include 'header.php'; ?>

      <div class="container-fluid">
          <h1 class="h3 mb-2 text-gray-800">Data Guru</h1>

          

        </div>

<?php include 'footer.php'; ?>
