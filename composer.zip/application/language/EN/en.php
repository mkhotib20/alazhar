<?php 
	$lang['heading_about'] = "Welcome";
 ?>